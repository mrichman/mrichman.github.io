using System;
using System.Collections;
using MarkRichman.Collections.WebService;

namespace MarkRichman.Collections.Client
{
	/// <summary>
	/// Summary description for CollectionsClient.
	/// </summary>
	class CollectionsClient
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			CollectionsHelper helper = new CollectionsHelper();

			Hashtable ht = new Hashtable();
			ht["Zero"]  = 0;
			ht["One"]   = 1;
			ht["Two"]   = 2;
			ht["Three"] = 3;
			ht["Four"]  = 4;

			object[][] oo = helper.ToJaggedArray(ht);

			MarkRichman.Collections.WebService.CollectionsWS ws 
				= new MarkRichman.Collections.WebService.CollectionsWS();

			ws.SetHashtable(oo);
			oo = ws.GetHashtable();
		}
	}
}
