using System;
using System.Collections;

namespace MarkRichman.Collections.WebService
{
	/// <summary>
	/// Summary description for CollectionsHelper.
	/// </summary>
	public class CollectionsHelper
	{
		public object[][] ToJaggedArray(Hashtable ht)
		{
			object[][] oo = new object[ht.Count][];
			int i = 0;

			foreach (object key in ht.Keys)
			{
				oo[i] = new object[] { key, ht[key] };				
				i++;
			}
			return oo;
		}

		public Hashtable ToHashtable(object[][] oo)
		{
			Hashtable ht = new Hashtable(oo.Length);

			foreach(object[] pair in oo)
			{
				object key = pair[0];
				object value = pair[1];
				ht[key] = value;
			}
			return ht;
		}
	}
}
