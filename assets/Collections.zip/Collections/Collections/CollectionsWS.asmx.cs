using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace MarkRichman.Collections.WebService
{
	/// <summary>
	/// Summary description for CollectionsWS.
	/// </summary>
	[WebService(Namespace="http://markrichman.com/webservices/")]
	public class CollectionsWS : System.Web.Services.WebService
	{
		private CollectionsHelper helper = null;
		private Hashtable ht = null;

		public CollectionsWS()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();

			this.helper = new CollectionsHelper();
			this.ht = new Hashtable(5);
			this.ht["Zero"]  = 0;
			this.ht["One"]   = 1;
			this.ht["Two"]   = 2;
			this.ht["Three"] = 3;
			this.ht["Four"]  = 4;
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		[WebMethod(Description="Returns the private Hashtable member variable " + 
		"as a jagged array suitable for XML serialization.")]
		public object[][] GetHashtable()
		{
			object[][] oo = helper.ToJaggedArray(this.ht);
			return oo;
		}

		[WebMethod(Description="Sets the private Hashtable member variable to " +
		"the jagged array passed via XML serialization.")]
		public void SetHashtable(object[][] oo)
		{
			this.ht = helper.ToHashtable(oo);
		}
	}
}
